"""
Insider Trading Detection API
================================
Unified interface that combines VPIN analysis with wallet clustering
to produce insider trading risk scores for prediction market contracts.

This is the main module to import in your app. It replaces simple scoring
with a multi-signal detection engine.

USAGE:
    from detection_api import InsiderDetector

    detector = InsiderDetector()

    # Score a single market
    score = detector.score_market(slug="some-market-slug")

    # Score with raw trade data you already have
    score = detector.score_from_trades(trades_df)

    # Scan multiple markets
    results = detector.scan_top_markets(n=20)

    # Get entity-level analysis
    entities = detector.cluster_wallets(trades_df, transfers_df)
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, asdict
from typing import Optional, Union
from datetime import datetime, timedelta, timezone

from vpin import VPINConfig, run_vpin_pipeline, compute_vpin, create_volume_buckets
from vpin import bulk_volume_classification, estimate_sigma
from wallet_clustering import WalletClusterer, ClusterConfig


# ---------------------------------------------------------------------------
# 1. RISK SCORE SCHEMA
# ---------------------------------------------------------------------------

@dataclass
class RiskScore:
    """
    Composite insider trading risk score for a market or entity.

    Fields
    ------
    overall_score : float [0-1]
        Composite risk score. 0 = no signal, 1 = very high risk.
    vpin_current : float [0-1]
        Most recent VPIN value.
    vpin_max : float [0-1]
        Peak VPIN in the analysis window.
    vpin_mean : float [0-1]
        Average VPIN across all buckets.
    vpin_trend : float [-1, 1]
        VPIN trend direction. Positive = increasing (getting riskier).
    volume_anomaly : float [0-1]
        How anomalous recent volume is vs. baseline.
    price_drift_score : float [0-1]
        Whether price is drifting toward a boundary (0 or 1) faster than
        historical vol would predict.
    n_alert_buckets : int
        Number of VPIN buckets exceeding the alert threshold.
    alert_pct : float
        Percentage of buckets that are alerts.
    entity_concentration : float [0-1]
        How concentrated the informed flow is among a few entities.
        High = a small number of wallets dominating.
    n_trades : int
        Number of trades analyzed.
    confidence : str
        'high', 'medium', 'low' — based on data quantity.
    details : dict
        Additional metadata (market name, timestamps, etc.)
    """
    overall_score: float = 0.0
    vpin_current: float = 0.0
    vpin_max: float = 0.0
    vpin_mean: float = 0.0
    vpin_trend: float = 0.0
    volume_anomaly: float = 0.0
    price_drift_score: float = 0.0
    n_alert_buckets: int = 0
    alert_pct: float = 0.0
    entity_concentration: float = 0.0
    n_trades: int = 0
    confidence: str = "low"
    details: dict = None

    def __post_init__(self):
        if self.details is None:
            self.details = {}

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        import json
        return json.dumps(self.to_dict(), indent=2, default=str)


# ---------------------------------------------------------------------------
# 2. SCORING FUNCTIONS
# ---------------------------------------------------------------------------

def compute_volume_anomaly(volumes: np.ndarray, lookback_pct: float = 0.7) -> float:
    """
    Compare recent volume to historical baseline.
    Returns 0-1 score where 1 = extreme anomaly.
    """
    split = int(len(volumes) * lookback_pct)
    if split < 10 or len(volumes) - split < 5:
        return 0.0

    baseline_mean = volumes[:split].mean()
    baseline_std = volumes[:split].std()

    if baseline_std < 1e-8:
        return 0.0

    recent_mean = volumes[split:].mean()
    z_score = (recent_mean - baseline_mean) / baseline_std

    # Sigmoid mapping to [0, 1]
    return float(1.0 / (1.0 + np.exp(-0.5 * (z_score - 2))))


def compute_price_drift(prices: np.ndarray, lookback_pct: float = 0.7) -> float:
    """
    Measure if price is drifting toward 0 or 1 (resolution boundaries)
    faster than random walk would predict.
    Returns 0-1 score.
    """
    split = int(len(prices) * lookback_pct)
    if split < 20:
        return 0.0

    # Historical volatility
    returns = np.diff(prices[:split])
    hist_vol = np.std(returns) if len(returns) > 1 else 1e-4

    # Recent drift
    recent = prices[split:]
    if len(recent) < 5:
        return 0.0

    # How far has price moved toward nearest boundary?
    start_price = recent[0]
    end_price = recent[-1]
    nearest_boundary = 1.0 if end_price > 0.5 else 0.0
    distance_start = abs(start_price - nearest_boundary)
    distance_end = abs(end_price - nearest_boundary)

    # Drift toward boundary
    drift = distance_start - distance_end  # positive = moving toward boundary

    # Normalize by what random walk would predict
    expected_drift = hist_vol * np.sqrt(len(recent))
    if expected_drift < 1e-8:
        return 0.0

    drift_ratio = drift / expected_drift

    # Sigmoid to [0, 1]
    return float(1.0 / (1.0 + np.exp(-1.0 * (drift_ratio - 1.5))))


def compute_vpin_trend(vpin_series: np.ndarray, window: int = 20) -> float:
    """
    Linear trend of VPIN. Positive = increasing informed trading.
    Returns [-1, 1].
    """
    if len(vpin_series) < window:
        window = len(vpin_series)
    if window < 3:
        return 0.0

    recent = vpin_series[-window:]
    x = np.arange(len(recent))
    slope = np.polyfit(x, recent, 1)[0]

    # Normalize: map typical slope range to [-1, 1]
    return float(np.clip(slope * 100, -1, 1))


def compute_entity_concentration(
    trades: pd.DataFrame,
    entities: Optional[pd.DataFrame] = None,
) -> float:
    """
    HHI-style concentration of trading volume by entity.
    High concentration = few entities dominating = suspicious.
    Returns 0-1.
    """
    if "wallet" not in trades.columns:
        return 0.0

    if entities is not None:
        # Map wallets to entities
        wallet_to_entity = dict(zip(entities["wallet"], entities["entity_id"]))
        trades = trades.copy()
        trades["entity"] = trades["wallet"].str.lower().map(wallet_to_entity)
        trades["entity"] = trades["entity"].fillna(trades["wallet"])
        group_col = "entity"
    else:
        group_col = "wallet"

    vol_by_group = trades.groupby(group_col)["size"].sum()
    total_vol = vol_by_group.sum()

    if total_vol <= 0:
        return 0.0

    shares = vol_by_group / total_vol
    hhi = (shares ** 2).sum()

    # Normalize: HHI ranges from 1/n to 1.0
    n = len(shares)
    if n <= 1:
        return 1.0

    min_hhi = 1.0 / n
    normalized = (hhi - min_hhi) / (1.0 - min_hhi)

    return float(np.clip(normalized, 0, 1))


# ---------------------------------------------------------------------------
# 3. COMPOSITE SCORING
# ---------------------------------------------------------------------------

# Signal weights for the composite score
DEFAULT_WEIGHTS = {
    "vpin_current": 0.25,
    "vpin_max": 0.15,
    "vpin_trend_positive": 0.15,
    "volume_anomaly": 0.15,
    "price_drift": 0.15,
    "alert_pct": 0.10,
    "entity_concentration": 0.05,
}


def compute_composite_score(
    vpin_current: float,
    vpin_max: float,
    vpin_trend: float,
    volume_anomaly: float,
    price_drift: float,
    alert_pct: float,
    entity_concentration: float,
    weights: Optional[dict] = None,
) -> float:
    """
    Weighted composite of all signals → single risk score [0, 1].
    """
    w = weights or DEFAULT_WEIGHTS

    score = (
        w["vpin_current"] * vpin_current +
        w["vpin_max"] * vpin_max +
        w["vpin_trend_positive"] * max(0, vpin_trend) +
        w["volume_anomaly"] * volume_anomaly +
        w["price_drift"] * price_drift +
        w["alert_pct"] * min(alert_pct / 100, 1.0) +
        w["entity_concentration"] * entity_concentration
    )

    return float(np.clip(score, 0, 1))


# ---------------------------------------------------------------------------
# 4. MAIN DETECTOR CLASS
# ---------------------------------------------------------------------------

class InsiderDetector:
    """
    Main entry point for insider trading detection.
    Drop-in replacement for a simple scoring algorithm.

    Example:
        detector = InsiderDetector()
        score = detector.score_from_trades(trades_df)
        print(f"Risk: {score.overall_score:.2f}")
        print(score.to_json())
    """

    def __init__(
        self,
        vpin_config: Optional[VPINConfig] = None,
        cluster_config: Optional[ClusterConfig] = None,
        score_weights: Optional[dict] = None,
    ):
        self.vpin_config = vpin_config or VPINConfig()
        self.cluster_config = cluster_config or ClusterConfig()
        self.score_weights = score_weights or DEFAULT_WEIGHTS

    def score_from_trades(
        self,
        trades: pd.DataFrame,
        transfers: Optional[pd.DataFrame] = None,
        market_name: str = "Unknown",
    ) -> RiskScore:
        """
        Score a market given trade data.

        Parameters
        ----------
        trades : DataFrame with columns: price, size, timestamp
                 Optional: wallet, side, token_id
        transfers : Optional DataFrame for wallet clustering
                    columns: from_address, to_address, value, timestamp
        market_name : label for the market

        Returns
        -------
        RiskScore with all signals and composite score
        """
        # Validate
        for col in ["price", "size", "timestamp"]:
            if col not in trades.columns:
                raise ValueError(f"Missing required column: {col}")

        trades = trades.copy()
        trades = trades[(trades["price"] > 0) & (trades["size"] > 0)].reset_index(drop=True)
        n_trades = len(trades)

        if n_trades < 20:
            return RiskScore(
                n_trades=n_trades,
                confidence="low",
                details={"market": market_name, "error": "Too few trades"},
            )

        prices = trades["price"].values
        volumes = trades["size"].values
        timestamps = trades["timestamp"].values

        # --- VPIN ---
        # Auto-tune bucket size
        total_vol = volumes.sum()
        bucket_size = max(10, int(total_vol / 300))
        config = VPINConfig(
            volume_bucket_size=bucket_size,
            n_buckets_window=self.vpin_config.n_buckets_window,
            sigma_window=self.vpin_config.sigma_window,
            alert_threshold=self.vpin_config.alert_threshold,
        )

        vpin_result = run_vpin_pipeline(prices, volumes, timestamps, config)
        buckets = vpin_result["buckets"]

        vpin_current = float(buckets["vpin"].iloc[-1]) if len(buckets) > 0 else 0.0
        vpin_max = float(buckets["vpin"].max()) if len(buckets) > 0 else 0.0
        vpin_mean = float(buckets["vpin"].mean()) if len(buckets) > 0 else 0.0
        n_alerts = len(vpin_result["alerts"])
        alert_pct = n_alerts / len(buckets) * 100 if len(buckets) > 0 else 0.0

        vpin_trend = compute_vpin_trend(buckets["vpin"].values)

        # --- Volume anomaly ---
        vol_anomaly = compute_volume_anomaly(volumes)

        # --- Price drift ---
        price_drift = compute_price_drift(prices)

        # --- Entity concentration ---
        entity_conc = 0.0
        entities = None
        if "wallet" in trades.columns and trades["wallet"].nunique() > 1:
            try:
                clusterer = WalletClusterer(self.cluster_config)
                clusterer.add_trades(trades)
                if transfers is not None:
                    clusterer.add_funding_links(transfers)
                entities = clusterer.cluster()
                entity_conc = compute_entity_concentration(trades, entities)
            except Exception as e:
                entity_conc = compute_entity_concentration(trades)

        # --- Composite score ---
        overall = compute_composite_score(
            vpin_current=vpin_current,
            vpin_max=vpin_max,
            vpin_trend=vpin_trend,
            volume_anomaly=vol_anomaly,
            price_drift=price_drift,
            alert_pct=alert_pct,
            entity_concentration=entity_conc,
            weights=self.score_weights,
        )

        # Confidence level
        if n_trades >= 500:
            confidence = "high"
        elif n_trades >= 100:
            confidence = "medium"
        else:
            confidence = "low"

        return RiskScore(
            overall_score=round(overall, 4),
            vpin_current=round(vpin_current, 4),
            vpin_max=round(vpin_max, 4),
            vpin_mean=round(vpin_mean, 4),
            vpin_trend=round(vpin_trend, 4),
            volume_anomaly=round(vol_anomaly, 4),
            price_drift_score=round(price_drift, 4),
            n_alert_buckets=n_alerts,
            alert_pct=round(alert_pct, 2),
            entity_concentration=round(entity_conc, 4),
            n_trades=n_trades,
            confidence=confidence,
            details={
                "market": market_name,
                "bucket_size": bucket_size,
                "n_buckets": len(buckets),
                "price_range": [float(prices.min()), float(prices.max())],
                "total_volume": float(total_vol),
                "n_entities": entities["entity_id"].nunique() if entities is not None else None,
            },
        )

    def score_market(
        self,
        slug: Optional[str] = None,
        token_id: Optional[str] = None,
        days_back: int = 30,
        max_trades: int = 10000,
    ) -> RiskScore:
        """
        Score a Polymarket market by slug or token ID.
        Fetches data from public APIs automatically.
        """
        from polymarket_vpin import (
            fetch_market_by_slug, get_token_ids, fetch_trades, preprocess_trades
        )

        market_name = slug or token_id or "Unknown"

        if slug:
            market = fetch_market_by_slug(slug)
            market_name = market.get("question", slug)
            tokens = get_token_ids(market)
            if not tokens:
                raise ValueError("No tokens found")
            token_id = tokens[0]["token_id"]

        since = datetime.now(timezone.utc) - timedelta(days=days_back)
        trades_df = fetch_trades(token_id, max_trades=max_trades, since=since)

        if len(trades_df) < 20:
            return RiskScore(
                n_trades=len(trades_df),
                confidence="low",
                details={"market": market_name, "error": "Insufficient trades"},
            )

        # Rename columns to match expected schema
        trades_df = trades_df.rename(columns={"size": "size"})
        if "size" not in trades_df.columns and "amount" in trades_df.columns:
            trades_df["size"] = trades_df["amount"]

        return self.score_from_trades(trades_df, market_name=market_name)

    def scan_top_markets(
        self,
        n: int = 20,
        days_back: int = 14,
        max_trades: int = 5000,
    ) -> pd.DataFrame:
        """
        Scan top Polymarket markets and return ranked risk scores.
        """
        from polymarket_vpin import fetch_markets, get_token_ids, fetch_trades

        markets = fetch_markets(limit=n, active=True, sort_by="volume")
        results = []

        for i, market in enumerate(markets):
            name = market.get("question", "?")[:60]
            print(f"[{i+1}/{len(markets)}] {name}")

            try:
                tokens = get_token_ids(market)
                if not tokens:
                    continue

                since = datetime.now(timezone.utc) - timedelta(days=days_back)
                trades_df = fetch_trades(
                    tokens[0]["token_id"],
                    max_trades=max_trades,
                    since=since,
                )

                if len(trades_df) < 20:
                    continue

                score = self.score_from_trades(trades_df, market_name=name)
                row = score.to_dict()
                row["slug"] = market.get("slug", "")
                row["market_volume"] = float(market.get("volume", 0))
                results.append(row)

            except Exception as e:
                print(f"  Error: {e}")
                continue

        if not results:
            return pd.DataFrame()

        df = pd.DataFrame(results)
        df = df.sort_values("overall_score", ascending=False).reset_index(drop=True)
        return df


# ---------------------------------------------------------------------------
# 5. DEMO
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    from vpin import generate_synthetic_prediction_market

    print("=" * 60)
    print("  Insider Trading Detection API — Demo")
    print("=" * 60)

    # Generate synthetic data
    prices, volumes, timestamps, insider_start = generate_synthetic_prediction_market(
        n_trades=5000,
        base_price=0.45,
        resolution_price=1.0,
        insider_start_pct=0.70,
        insider_intensity=3.0,
    )

    trades = pd.DataFrame({
        "price": prices,
        "size": volumes,
        "timestamp": timestamps,
    })

    # Run detection
    detector = InsiderDetector()
    score = detector.score_from_trades(trades, market_name="Synthetic Test Market")

    print(f"\n{score.to_json()}")

    # Interpret
    print(f"\n{'=' * 60}")
    print(f"  RISK ASSESSMENT")
    print(f"{'=' * 60}")

    level = "LOW"
    if score.overall_score >= 0.6:
        level = "HIGH"
    elif score.overall_score >= 0.35:
        level = "MEDIUM"

    print(f"\n  Overall Risk: {score.overall_score:.2f} ({level})")
    print(f"  Confidence: {score.confidence}")
    print(f"\n  Signal Breakdown:")
    print(f"    VPIN (current):      {score.vpin_current:.3f}")
    print(f"    VPIN (max):          {score.vpin_max:.3f}")
    print(f"    VPIN trend:          {score.vpin_trend:+.3f}")
    print(f"    Volume anomaly:      {score.volume_anomaly:.3f}")
    print(f"    Price drift:         {score.price_drift_score:.3f}")
    print(f"    Alert buckets:       {score.n_alert_buckets} ({score.alert_pct:.1f}%)")
    print(f"    Entity concentration:{score.entity_concentration:.3f}")
