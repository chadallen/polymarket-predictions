"""
Wallet Clustering — On-Chain Entity Resolution
================================================
Links multiple wallets to the same controlling entity using:
1. Funding source analysis (common ancestor wallets)
2. Temporal trade clustering (correlated timing)
3. Cross-market co-movement (same wallets winning across markets)
4. Behavioral fingerprinting (order size distributions, active hours)

Designed for Polygon (Polymarket) but adaptable to any EVM chain.

USAGE:
    from wallet_clustering import WalletClusterer
    clusterer = WalletClusterer()
    clusterer.add_trades(trades_df)          # feed in trade data
    clusterer.add_funding_links(transfers)   # feed in on-chain transfers
    entities = clusterer.cluster()           # get entity clusters
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from collections import defaultdict
from typing import Optional
from scipy.spatial.distance import cosine
from scipy.cluster.hierarchy import fcluster, linkage


# ---------------------------------------------------------------------------
# 1. CONFIGURATION
# ---------------------------------------------------------------------------

@dataclass
class ClusterConfig:
    """Tunable parameters for wallet clustering."""

    # Funding analysis
    funding_hop_depth: int = 3              # how many hops back to trace funding
    common_funder_weight: float = 0.5       # similarity weight for shared funding source

    # Temporal clustering
    time_window_seconds: float = 60.0       # trades within this window are "simultaneous"
    temporal_corr_weight: float = 0.25      # similarity weight for timing correlation

    # Behavioral fingerprinting
    behavior_weight: float = 0.15           # similarity weight for behavioral similarity
    n_size_bins: int = 10                   # bins for order size distribution
    n_hour_bins: int = 24                   # bins for active hours (24 = hourly)

    # Cross-market co-movement
    comovement_weight: float = 0.10         # similarity weight for cross-market patterns

    # Clustering
    similarity_threshold: float = 0.35      # minimum similarity to consider linking
    linkage_method: str = "average"         # hierarchical clustering linkage method

    # Filtering
    min_trades_per_wallet: int = 3          # ignore wallets with fewer trades


# ---------------------------------------------------------------------------
# 2. FEATURE EXTRACTORS
# ---------------------------------------------------------------------------

def extract_funding_graph(transfers: pd.DataFrame, hop_depth: int = 3) -> dict:
    """
    Build a funding ancestry graph from on-chain transfer data.

    Parameters
    ----------
    transfers : DataFrame with columns: from_address, to_address, value, timestamp
                These are token/native transfers on Polygon.
    hop_depth : how many hops backward to trace

    Returns
    -------
    dict mapping wallet -> set of ancestor wallets (within hop_depth)
    """
    # Build adjacency: who funded whom
    children = defaultdict(set)  # funder -> set of funded wallets
    parents = defaultdict(set)   # wallet -> set of funders

    for _, row in transfers.iterrows():
        sender = row["from_address"].lower()
        receiver = row["to_address"].lower()
        parents[receiver].add(sender)
        children[sender].add(receiver)

    # BFS backward from each wallet to find ancestors
    ancestors = {}
    for wallet in set(transfers["to_address"].str.lower()) | set(transfers["from_address"].str.lower()):
        visited = set()
        frontier = {wallet}
        for hop in range(hop_depth):
            next_frontier = set()
            for w in frontier:
                for parent in parents.get(w, set()):
                    if parent not in visited and parent != wallet:
                        visited.add(parent)
                        next_frontier.add(parent)
            frontier = next_frontier
        ancestors[wallet] = visited

    return ancestors


def compute_funding_similarity(ancestors: dict, wallet_a: str, wallet_b: str) -> float:
    """
    Jaccard similarity of funding ancestors.
    Higher = more likely same entity.
    """
    set_a = ancestors.get(wallet_a, set())
    set_b = ancestors.get(wallet_b, set())

    if not set_a and not set_b:
        return 0.0

    intersection = set_a & set_b
    union = set_a | set_b

    if not union:
        return 0.0

    return len(intersection) / len(union)


def extract_temporal_features(trades: pd.DataFrame, time_window: float = 60.0) -> dict:
    """
    For each wallet, build a vector of trade timing relative to other wallets.

    We create a "co-trading" matrix: for each pair of wallets, count how many
    times they traded within `time_window` seconds of each other on the same
    contract/token.

    Returns
    -------
    dict of wallet -> {other_wallet: co_trade_count}
    """
    trades = trades.copy()
    trades["ts_epoch"] = pd.to_datetime(trades["timestamp"]).astype(np.int64) / 1e9

    co_trades = defaultdict(lambda: defaultdict(int))

    # Group by token/market to find co-trading within the same market
    group_col = "token_id" if "token_id" in trades.columns else "market_id"
    if group_col not in trades.columns:
        # If no market grouping available, use all trades
        groups = [("all", trades)]
    else:
        groups = trades.groupby(group_col)

    for _, group in groups:
        group = group.sort_values("ts_epoch")
        wallets = group["wallet"].str.lower().values
        times = group["ts_epoch"].values

        # Sliding window approach
        for i in range(len(group)):
            j = i + 1
            while j < len(group) and (times[j] - times[i]) <= time_window:
                if wallets[i] != wallets[j]:
                    co_trades[wallets[i]][wallets[j]] += 1
                    co_trades[wallets[j]][wallets[i]] += 1
                j += 1

    return dict(co_trades)


def compute_temporal_similarity(co_trades: dict, wallet_a: str, wallet_b: str,
                                  max_co_trades: int = 1) -> float:
    """
    Normalized co-trading frequency.
    """
    count = co_trades.get(wallet_a, {}).get(wallet_b, 0)
    if max_co_trades <= 0:
        max_co_trades = 1
    return min(count / max_co_trades, 1.0)


def extract_behavioral_features(
    trades: pd.DataFrame,
    n_size_bins: int = 10,
    n_hour_bins: int = 24,
) -> dict:
    """
    For each wallet, extract behavioral fingerprint:
    - Order size distribution (histogram)
    - Active hours distribution
    - Buy/sell ratio
    - Mean time between trades

    Returns
    -------
    dict of wallet -> feature vector (numpy array)
    """
    trades = trades.copy()
    trades["wallet"] = trades["wallet"].str.lower()
    trades["timestamp"] = pd.to_datetime(trades["timestamp"])

    # Global size bins (quantile-based)
    size_bins = np.quantile(trades["size"], np.linspace(0, 1, n_size_bins + 1))
    size_bins[-1] = np.inf
    size_bins[0] = 0

    features = {}

    for wallet, group in trades.groupby("wallet"):
        # Order size distribution
        size_hist, _ = np.histogram(group["size"], bins=size_bins)
        size_hist = size_hist / (size_hist.sum() + 1e-10)

        # Active hours distribution
        hours = group["timestamp"].dt.hour.values
        hour_hist, _ = np.histogram(hours, bins=np.arange(n_hour_bins + 1))
        hour_hist = hour_hist / (hour_hist.sum() + 1e-10)

        # Buy/sell ratio
        if "side" in group.columns:
            n_buys = (group["side"].str.lower() == "buy").sum()
            buy_ratio = n_buys / len(group)
        else:
            buy_ratio = 0.5

        # Mean inter-trade time (in minutes)
        if len(group) > 1:
            sorted_times = group["timestamp"].sort_values()
            diffs = sorted_times.diff().dropna().dt.total_seconds() / 60
            mean_interval = min(diffs.mean() / 1440, 1.0)  # normalize by 1 day
        else:
            mean_interval = 1.0

        # Concatenate into feature vector
        feature_vec = np.concatenate([
            size_hist,           # n_size_bins features
            hour_hist,           # n_hour_bins features
            [buy_ratio],         # 1 feature
            [mean_interval],     # 1 feature
        ])

        features[wallet] = feature_vec

    return features


def compute_behavioral_similarity(features: dict, wallet_a: str, wallet_b: str) -> float:
    """
    1 - cosine distance between behavioral feature vectors.
    """
    vec_a = features.get(wallet_a)
    vec_b = features.get(wallet_b)

    if vec_a is None or vec_b is None:
        return 0.0

    # Handle zero vectors
    if np.allclose(vec_a, 0) or np.allclose(vec_b, 0):
        return 0.0

    return 1.0 - cosine(vec_a, vec_b)


def extract_cross_market_features(trades: pd.DataFrame) -> dict:
    """
    For each wallet, compute a vector of which markets they're active in
    and which side they took. Wallets that consistently appear on the same
    side of the same markets are likely the same entity.

    Returns
    -------
    dict of wallet -> market participation vector
    """
    trades = trades.copy()
    trades["wallet"] = trades["wallet"].str.lower()

    market_col = "token_id" if "token_id" in trades.columns else "market_id"
    if market_col not in trades.columns:
        return {}

    markets = trades[market_col].unique()
    market_idx = {m: i for i, m in enumerate(markets)}

    features = {}
    for wallet, group in trades.groupby("wallet"):
        vec = np.zeros(len(markets) * 2)  # 2 per market: buy intensity, sell intensity
        for _, trade in group.iterrows():
            idx = market_idx[trade[market_col]]
            vol = trade.get("size", 1)
            side = trade.get("side", "buy").lower()
            if side == "buy":
                vec[idx * 2] += vol
            else:
                vec[idx * 2 + 1] += vol

        # Normalize
        total = vec.sum()
        if total > 0:
            vec = vec / total

        features[wallet] = vec

    return features


# ---------------------------------------------------------------------------
# 3. MAIN CLUSTERER
# ---------------------------------------------------------------------------

class WalletClusterer:
    """
    Combines multiple similarity signals to cluster wallets into entities.

    Usage:
        clusterer = WalletClusterer(config)
        clusterer.add_trades(trades_df)
        clusterer.add_funding_links(transfers_df)  # optional
        entities = clusterer.cluster()
    """

    def __init__(self, config: Optional[ClusterConfig] = None):
        self.config = config or ClusterConfig()
        self.trades: Optional[pd.DataFrame] = None
        self.transfers: Optional[pd.DataFrame] = None

        # Computed features
        self._ancestors = None
        self._co_trades = None
        self._behavioral = None
        self._cross_market = None
        self._wallets = None

    def add_trades(self, trades: pd.DataFrame):
        """
        Add trade data. Required columns: wallet, timestamp, size, price.
        Optional columns: side, token_id/market_id.
        """
        required = {"wallet", "timestamp", "size", "price"}
        missing = required - set(trades.columns)
        if missing:
            raise ValueError(f"Missing columns: {missing}")

        self.trades = trades.copy()
        self.trades["wallet"] = self.trades["wallet"].str.lower()

    def add_funding_links(self, transfers: pd.DataFrame):
        """
        Add on-chain transfer data for funding analysis.
        Required columns: from_address, to_address, value, timestamp.
        """
        self.transfers = transfers.copy()

    def _extract_features(self):
        """Compute all feature sets."""
        if self.trades is None:
            raise ValueError("No trade data added. Call add_trades() first.")

        # Filter low-activity wallets
        counts = self.trades["wallet"].value_counts()
        active = counts[counts >= self.config.min_trades_per_wallet].index
        trades_filtered = self.trades[self.trades["wallet"].isin(active)]
        self._wallets = sorted(active.tolist())

        print(f"  Wallets after filtering (>={self.config.min_trades_per_wallet} trades): "
              f"{len(self._wallets)}")

        # Funding graph
        if self.transfers is not None and len(self.transfers) > 0:
            print("  Computing funding ancestry...")
            self._ancestors = extract_funding_graph(
                self.transfers, self.config.funding_hop_depth
            )
        else:
            self._ancestors = {}

        # Temporal co-trading
        print("  Computing temporal co-trading...")
        self._co_trades = extract_temporal_features(
            trades_filtered, self.config.time_window_seconds
        )

        # Behavioral fingerprints
        print("  Extracting behavioral fingerprints...")
        self._behavioral = extract_behavioral_features(
            trades_filtered, self.config.n_size_bins, self.config.n_hour_bins
        )

        # Cross-market co-movement
        print("  Computing cross-market co-movement...")
        self._cross_market = extract_cross_market_features(trades_filtered)

    def _compute_pairwise_similarity(self) -> np.ndarray:
        """
        Compute weighted pairwise similarity matrix across all signals.
        """
        n = len(self._wallets)
        sim_matrix = np.zeros((n, n))

        cfg = self.config

        # Find max co-trades for normalization
        max_co = 1
        for w_trades in self._co_trades.values():
            for count in w_trades.values():
                max_co = max(max_co, count)

        print(f"  Computing {n * (n-1) // 2} pairwise similarities...")

        for i in range(n):
            for j in range(i + 1, n):
                wa, wb = self._wallets[i], self._wallets[j]

                # Funding similarity
                s_fund = 0.0
                if self._ancestors:
                    s_fund = compute_funding_similarity(self._ancestors, wa, wb)

                # Temporal similarity
                s_temp = compute_temporal_similarity(self._co_trades, wa, wb, max_co)

                # Behavioral similarity
                s_behav = compute_behavioral_similarity(self._behavioral, wa, wb)

                # Cross-market similarity
                s_cross = 0.0
                if self._cross_market and wa in self._cross_market and wb in self._cross_market:
                    va, vb = self._cross_market[wa], self._cross_market[wb]
                    if not (np.allclose(va, 0) or np.allclose(vb, 0)):
                        s_cross = 1.0 - cosine(va, vb)

                # Weighted combination
                similarity = (
                    cfg.common_funder_weight * s_fund +
                    cfg.temporal_corr_weight * s_temp +
                    cfg.behavior_weight * s_behav +
                    cfg.comovement_weight * s_cross
                )

                sim_matrix[i, j] = similarity
                sim_matrix[j, i] = similarity

        return sim_matrix

    def cluster(self) -> pd.DataFrame:
        """
        Run the full clustering pipeline.

        Returns
        -------
        DataFrame with columns: wallet, entity_id, entity_size,
                                plus similarity scores per signal
        """
        print("\n🔗 Wallet Clustering — Entity Resolution")
        print("=" * 50)

        self._extract_features()

        if len(self._wallets) < 2:
            print("  Not enough wallets to cluster.")
            return pd.DataFrame({
                "wallet": self._wallets,
                "entity_id": range(len(self._wallets)),
                "entity_size": [1] * len(self._wallets),
            })

        sim_matrix = self._compute_pairwise_similarity()

        # Convert similarity to distance for hierarchical clustering
        dist_matrix = 1.0 - sim_matrix
        np.fill_diagonal(dist_matrix, 0)

        # Condensed distance matrix for scipy
        from scipy.spatial.distance import squareform
        condensed = squareform(dist_matrix, checks=False)

        # Hierarchical clustering
        Z = linkage(condensed, method=self.config.linkage_method)
        threshold = 1.0 - self.config.similarity_threshold
        labels = fcluster(Z, t=threshold, criterion="distance")

        # Build result DataFrame
        results = pd.DataFrame({
            "wallet": self._wallets,
            "entity_id": labels,
        })

        entity_sizes = results["entity_id"].value_counts().to_dict()
        results["entity_size"] = results["entity_id"].map(entity_sizes)

        # Sort: largest entities first, then by entity_id
        results = results.sort_values(
            ["entity_size", "entity_id"], ascending=[False, True]
        ).reset_index(drop=True)

        # Summary
        n_entities = results["entity_id"].nunique()
        multi_wallet = results[results["entity_size"] > 1]
        n_multi = multi_wallet["entity_id"].nunique()
        largest = results["entity_size"].max()

        print(f"\n  Results:")
        print(f"    Total wallets: {len(self._wallets)}")
        print(f"    Entities identified: {n_entities}")
        print(f"    Multi-wallet entities: {n_multi}")
        print(f"    Largest entity: {largest} wallets")

        if n_multi > 0:
            print(f"\n  ⚠ Multi-wallet entities:")
            for eid in multi_wallet["entity_id"].unique()[:10]:
                ew = results[results["entity_id"] == eid]["wallet"].tolist()
                print(f"    Entity {eid}: {len(ew)} wallets")
                for w in ew[:5]:
                    print(f"      {w}")
                if len(ew) > 5:
                    print(f"      ... and {len(ew) - 5} more")

        return results

    def get_entity_trades(self, entities: pd.DataFrame, entity_id: int) -> pd.DataFrame:
        """Get all trades for a given entity (across all its wallets)."""
        wallets = entities[entities["entity_id"] == entity_id]["wallet"].tolist()
        return self.trades[self.trades["wallet"].isin(wallets)]

    def entity_vpin(self, entities: pd.DataFrame, entity_id: int,
                     config=None) -> dict:
        """
        Run VPIN on an entity's aggregated trades.
        Useful for checking if a specific entity cluster is trading informed.
        """
        from vpin import VPINConfig, run_vpin_pipeline

        if config is None:
            config = VPINConfig()

        entity_trades = self.get_entity_trades(entities, entity_id)
        if len(entity_trades) < 10:
            return {"error": "Too few trades for this entity"}

        entity_trades = entity_trades.sort_values("timestamp")
        prices = entity_trades["price"].values
        volumes = entity_trades["size"].values
        timestamps = entity_trades["timestamp"].values

        return run_vpin_pipeline(prices, volumes, timestamps, config)


# ---------------------------------------------------------------------------
# 4. SYNTHETIC DATA GENERATOR (for testing)
# ---------------------------------------------------------------------------

def generate_synthetic_wallet_data(
    n_honest_wallets: int = 50,
    n_sybil_entities: int = 3,
    wallets_per_sybil: int = 5,
    n_markets: int = 5,
    trades_per_wallet: int = 30,
    seed: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Generate synthetic trade and transfer data with known sybil clusters.

    Returns
    -------
    trades_df, transfers_df, ground_truth (dict of entity -> wallets)
    """
    rng = np.random.default_rng(seed)

    all_trades = []
    all_transfers = []
    ground_truth = {}

    wallet_counter = 0

    def make_wallet():
        nonlocal wallet_counter
        wallet_counter += 1
        return f"0x{wallet_counter:040x}"

    # Funding source wallets (exchanges, etc.)
    funding_sources = [make_wallet() for _ in range(5)]
    markets = [f"market_{i}" for i in range(n_markets)]

    base_time = pd.Timestamp("2025-01-15 09:00:00", tz="UTC")

    # --- Honest wallets ---
    for i in range(n_honest_wallets):
        wallet = make_wallet()
        funder = rng.choice(funding_sources)

        # Funding transfer
        all_transfers.append({
            "from_address": funder,
            "to_address": wallet,
            "value": rng.uniform(100, 10000),
            "timestamp": base_time - pd.Timedelta(days=rng.integers(1, 30)),
        })

        # Random trades across random markets
        active_markets = rng.choice(markets, size=rng.integers(1, 4), replace=False)
        preferred_hour = rng.integers(0, 24)
        preferred_size = rng.lognormal(2, 1)

        for _ in range(trades_per_wallet):
            market = rng.choice(active_markets)
            trade_time = base_time + pd.Timedelta(
                hours=rng.normal(preferred_hour, 4) % 24,
                minutes=rng.integers(0, 60),
                days=rng.integers(0, 14),
            )
            all_trades.append({
                "wallet": wallet,
                "timestamp": trade_time,
                "price": rng.uniform(0.1, 0.9),
                "size": max(1, rng.lognormal(np.log(preferred_size), 0.8)),
                "side": rng.choice(["buy", "sell"]),
                "token_id": market,
            })

    # --- Sybil entities (insider clusters) ---
    for entity_idx in range(n_sybil_entities):
        # Shared characteristics
        shared_funder = make_wallet()  # intermediate wallet
        source = rng.choice(funding_sources)
        all_transfers.append({
            "from_address": source,
            "to_address": shared_funder,
            "value": rng.uniform(10000, 100000),
            "timestamp": base_time - pd.Timedelta(days=rng.integers(5, 20)),
        })

        entity_wallets = []
        preferred_hour = rng.integers(0, 24)
        preferred_size = rng.lognormal(3, 0.5)
        target_markets = rng.choice(markets, size=rng.integers(2, 4), replace=False)

        for w_idx in range(wallets_per_sybil):
            wallet = make_wallet()
            entity_wallets.append(wallet)

            # Funded from shared intermediate (the giveaway)
            all_transfers.append({
                "from_address": shared_funder,
                "to_address": wallet,
                "value": rng.uniform(1000, 5000),
                "timestamp": base_time - pd.Timedelta(
                    days=rng.integers(1, 5),
                    hours=rng.integers(0, 3),
                ),
            })

            for _ in range(trades_per_wallet):
                market = rng.choice(target_markets)
                # Correlated timing (within a few minutes of each other)
                base_trade_time = base_time + pd.Timedelta(
                    hours=rng.normal(preferred_hour, 2) % 24,
                    days=rng.integers(0, 14),
                )
                jitter = pd.Timedelta(seconds=rng.uniform(0, 45))

                all_trades.append({
                    "wallet": wallet,
                    "timestamp": base_trade_time + jitter,
                    "price": rng.uniform(0.1, 0.9),
                    "size": max(1, rng.lognormal(np.log(preferred_size), 0.3)),
                    "side": "buy",  # sybils trade directionally
                    "token_id": market,
                })

        ground_truth[f"sybil_entity_{entity_idx}"] = entity_wallets

    trades_df = pd.DataFrame(all_trades)
    transfers_df = pd.DataFrame(all_transfers)

    return trades_df, transfers_df, ground_truth


# ---------------------------------------------------------------------------
# 5. DEMO
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    print("=" * 60)
    print("  Wallet Clustering — Entity Resolution Demo")
    print("=" * 60)

    # Generate synthetic data with known sybil clusters
    trades, transfers, ground_truth = generate_synthetic_wallet_data(
        n_honest_wallets=40,
        n_sybil_entities=3,
        wallets_per_sybil=5,
        n_markets=5,
        trades_per_wallet=25,
    )

    print(f"\nSynthetic data generated:")
    print(f"  Trades: {len(trades):,}")
    print(f"  Wallets: {trades['wallet'].nunique()}")
    print(f"  Transfers: {len(transfers)}")
    print(f"  Known sybil entities: {len(ground_truth)}")
    for name, wallets in ground_truth.items():
        print(f"    {name}: {len(wallets)} wallets")

    # Run clustering
    clusterer = WalletClusterer(ClusterConfig(
        similarity_threshold=0.30,
        min_trades_per_wallet=3,
    ))
    clusterer.add_trades(trades)
    clusterer.add_funding_links(transfers)

    entities = clusterer.cluster()

    # Evaluate against ground truth
    print(f"\n{'=' * 60}")
    print(f"  EVALUATION vs GROUND TRUTH")
    print(f"{'=' * 60}")

    for name, true_wallets in ground_truth.items():
        # Find which entity_ids these wallets were assigned to
        assigned = entities[entities["wallet"].isin(true_wallets)]
        entity_ids = assigned["entity_id"].unique()

        if len(entity_ids) == 1:
            # Check if the cluster is pure (no extra wallets)
            cluster_wallets = entities[entities["entity_id"] == entity_ids[0]]["wallet"].tolist()
            extra = set(cluster_wallets) - set(true_wallets)
            print(f"\n  {name}:")
            print(f"    ✓ All {len(true_wallets)} wallets in single cluster (entity {entity_ids[0]})")
            if extra:
                print(f"    ⚠ Cluster also contains {len(extra)} extra wallet(s)")
            else:
                print(f"    ✓ Cluster is pure (no false positives)")
        else:
            print(f"\n  {name}:")
            print(f"    ✗ Wallets split across {len(entity_ids)} clusters: {entity_ids}")
            for eid in entity_ids:
                n_in = len(assigned[assigned["entity_id"] == eid])
                print(f"      Entity {eid}: {n_in} of {len(true_wallets)} sybil wallets")
