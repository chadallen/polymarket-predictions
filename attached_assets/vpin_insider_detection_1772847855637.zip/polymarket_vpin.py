"""
Polymarket → VPIN Pipeline
===========================
Fetches real trade data from Polymarket's public APIs and runs
VPIN analysis to detect potential informed trading.

USAGE:
    # Analyze a specific market by condition ID or slug:
    python polymarket_vpin.py --slug "will-trump-win-the-2024-presidential-election"
    python polymarket_vpin.py --token-id "12345..."

    # With custom VPIN parameters:
    python polymarket_vpin.py --slug "some-market" --bucket-size 100 --window 30 --threshold 0.4

    # List trending / active markets:
    python polymarket_vpin.py --list-markets

REQUIREMENTS:
    pip install requests pandas numpy scipy matplotlib

APIs used (no auth required):
    - Gamma API:  https://gamma-api.polymarket.com  (market metadata)
    - CLOB API:   https://clob.polymarket.com       (trade history)
"""

import argparse
import time
import json
import sys
from datetime import datetime, timedelta, timezone
from typing import Optional

import numpy as np
import pandas as pd
import requests
import matplotlib.pyplot as plt

# Import VPIN pipeline from the core module
from vpin import VPINConfig, run_vpin_pipeline, plot_vpin_analysis


# ---------------------------------------------------------------------------
# 1. POLYMARKET API CLIENTS
# ---------------------------------------------------------------------------

GAMMA_API = "https://gamma-api.polymarket.com"
CLOB_API = "https://clob.polymarket.com"

# Rate limiting helper
_last_request_time = 0

def _rate_limit(min_interval: float = 0.25):
    """Simple rate limiter to avoid hammering the API."""
    global _last_request_time
    elapsed = time.time() - _last_request_time
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)
    _last_request_time = time.time()


def fetch_markets(
    query: str = "",
    limit: int = 20,
    active: bool = True,
    sort_by: str = "volume",
) -> list[dict]:
    """
    Fetch markets from Gamma API.

    Parameters
    ----------
    query : search term
    limit : max results
    active : only active (unresolved) markets
    sort_by : 'volume', 'liquidity', 'created_at', 'end_date'

    Returns
    -------
    List of market dicts with keys: id, question, slug, tokens, volume, etc.
    """
    _rate_limit()
    params = {
        "limit": limit,
        "active": str(active).lower(),
        "order": sort_by,
        "ascending": "false",
    }
    if query:
        params["search"] = query

    resp = requests.get(f"{GAMMA_API}/markets", params=params, timeout=15)
    resp.raise_for_status()
    return resp.json()


def fetch_market_by_slug(slug: str) -> dict:
    """Fetch a single market by its URL slug."""
    _rate_limit()
    resp = requests.get(f"{GAMMA_API}/markets", params={"slug": slug}, timeout=15)
    resp.raise_for_status()
    markets = resp.json()
    if not markets:
        raise ValueError(f"No market found with slug: {slug}")
    return markets[0]


def fetch_market_by_id(condition_id: str) -> dict:
    """Fetch a single market by condition ID."""
    _rate_limit()
    resp = requests.get(f"{GAMMA_API}/markets/{condition_id}", timeout=15)
    resp.raise_for_status()
    return resp.json()


def get_token_ids(market: dict) -> list[dict]:
    """
    Extract token IDs from a market.
    Each market has YES and NO outcome tokens.

    Returns list of dicts: [{outcome: "Yes", token_id: "..."}, ...]
    """
    tokens = []

    # Gamma API returns tokens as a JSON string or list
    raw_tokens = market.get("tokens", [])
    if isinstance(raw_tokens, str):
        raw_tokens = json.loads(raw_tokens)

    for token in raw_tokens:
        tokens.append({
            "outcome": token.get("outcome", "Unknown"),
            "token_id": token.get("token_id", ""),
        })

    # Fallback: clobTokenIds field
    if not tokens:
        clob_ids = market.get("clobTokenIds", "")
        if isinstance(clob_ids, str):
            try:
                clob_ids = json.loads(clob_ids)
            except json.JSONDecodeError:
                clob_ids = []
        for i, tid in enumerate(clob_ids):
            tokens.append({
                "outcome": "Yes" if i == 0 else "No",
                "token_id": tid,
            })

    return tokens


def fetch_trades(
    token_id: str,
    limit_per_page: int = 500,
    max_trades: int = 10000,
    since: Optional[datetime] = None,
) -> pd.DataFrame:
    """
    Fetch trade history for a specific outcome token from the CLOB API.

    Parameters
    ----------
    token_id : the CLOB token ID (from get_token_ids)
    limit_per_page : page size (max 500)
    max_trades : stop after this many trades
    since : only fetch trades after this datetime

    Returns
    -------
    DataFrame with columns: timestamp, price, size, side
    """
    all_trades = []
    cursor = None
    total_fetched = 0

    print(f"  Fetching trades for token {token_id[:16]}...")

    while total_fetched < max_trades:
        _rate_limit(0.3)

        params = {
            "asset_id": token_id,
            "limit": min(limit_per_page, max_trades - total_fetched),
        }
        if cursor:
            params["cursor"] = cursor

        try:
            resp = requests.get(f"{CLOB_API}/trades", params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
        except requests.RequestException as e:
            print(f"  ⚠ API error: {e}")
            break

        trades = data.get("data", data) if isinstance(data, dict) else data

        # Handle paginated response
        if isinstance(data, dict):
            trades = data.get("data", [])
            cursor = data.get("next_cursor", None)
        else:
            trades = data
            cursor = None

        if not trades:
            break

        for t in trades:
            ts = t.get("timestamp") or t.get("created_at") or t.get("match_time")
            price = float(t.get("price", 0))
            size = float(t.get("size", t.get("amount", 0)))
            side = t.get("side", "unknown")

            # Parse timestamp
            if isinstance(ts, (int, float)):
                # Unix seconds or milliseconds
                if ts > 1e12:
                    ts = ts / 1000
                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
            elif isinstance(ts, str):
                dt = pd.to_datetime(ts, utc=True)
            else:
                dt = pd.Timestamp.now(tz="UTC")

            if since and dt < since.replace(tzinfo=timezone.utc):
                continue

            all_trades.append({
                "timestamp": dt,
                "price": price,
                "size": size,
                "side": side,
            })

        total_fetched += len(trades)
        print(f"    ... {total_fetched} trades fetched", end="\r")

        if not cursor:
            break

    print(f"    ✓ {len(all_trades)} trades fetched" + " " * 20)

    if not all_trades:
        return pd.DataFrame(columns=["timestamp", "price", "size", "side"])

    df = pd.DataFrame(all_trades)
    df = df.sort_values("timestamp").reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# 2. DATA PREPROCESSING
# ---------------------------------------------------------------------------

def preprocess_trades(trades_df: pd.DataFrame) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Clean and prepare trade data for VPIN pipeline.

    Returns: prices, volumes, timestamps (as numpy arrays)
    """
    df = trades_df.copy()

    # Drop zero-price or zero-volume trades
    df = df[(df["price"] > 0) & (df["size"] > 0)].reset_index(drop=True)

    if len(df) == 0:
        raise ValueError("No valid trades after filtering")

    prices = df["price"].values
    volumes = df["size"].values
    timestamps = df["timestamp"].values

    return prices, volumes, timestamps


# ---------------------------------------------------------------------------
# 3. ENHANCED PLOTTING (with timestamps)
# ---------------------------------------------------------------------------

def plot_polymarket_vpin(result: dict, market_info: dict,
                          save_path: Optional[str] = None):
    """
    Visualization tailored for Polymarket data.
    """
    trades = result["trades"]
    buckets = result["buckets"]
    config = result["config"]

    question = market_info.get("question", "Unknown Market")

    fig, axes = plt.subplots(4, 1, figsize=(14, 12),
                              gridspec_kw={"hspace": 0.35})

    # --- Panel 1: Price ---
    ax1 = axes[0]
    if "timestamp" in trades.columns:
        x_axis = pd.to_datetime(trades["timestamp"])
        ax1.plot(x_axis, trades["price"], color="#2563eb", linewidth=0.7, alpha=0.9)
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%m/%d"))
        ax1.xaxis.set_major_locator(mdates.AutoDateLocator())
    else:
        ax1.plot(trades["price"].values, color="#2563eb", linewidth=0.7, alpha=0.9)
    ax1.set_ylabel("Contract Price", fontsize=10)
    ax1.set_title(f"VPIN Analysis — {question[:80]}", fontsize=12, fontweight="bold")
    ax1.grid(True, alpha=0.3)

    # --- Panel 2: Volume ---
    ax2 = axes[1]
    if "timestamp" in trades.columns:
        ax2.bar(x_axis, trades["volume"], color="#6366f1", alpha=0.5, width=0.01)
        ax2.xaxis.set_major_formatter(mdates.DateFormatter("%m/%d"))
    else:
        ax2.bar(range(len(trades)), trades["volume"], color="#6366f1", alpha=0.5, width=1.0)
    ax2.set_ylabel("Trade Size", fontsize=10)
    ax2.grid(True, alpha=0.3)

    # --- Panel 3: Order Imbalance ---
    ax3 = axes[2]
    ax3.bar(buckets["bucket_id"], buckets["norm_imbalance"],
            color="#f59e0b", alpha=0.6, width=1.0)
    ax3.set_ylabel("Order Imbalance", fontsize=10)
    ax3.grid(True, alpha=0.3)

    # --- Panel 4: VPIN ---
    ax4 = axes[3]
    ax4.plot(buckets["bucket_id"], buckets["vpin"],
             color="#059669", linewidth=1.5, label="VPIN")
    ax4.axhline(config.alert_threshold, color="#dc2626", linestyle="--",
                linewidth=1.2, label=f"Alert Threshold ({config.alert_threshold})")
    ax4.fill_between(buckets["bucket_id"], buckets["vpin"], config.alert_threshold,
                     where=buckets["vpin"] >= config.alert_threshold,
                     color="#dc2626", alpha=0.2)
    ax4.set_ylabel("VPIN", fontsize=10)
    ax4.set_xlabel("Volume Bucket", fontsize=10)
    ax4.legend(fontsize=9)
    ax4.set_ylim(0, 1)
    ax4.grid(True, alpha=0.3)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Plot saved to {save_path}")
    else:
        plt.show()

    plt.close()

# Need this import at module level for DateFormatter
import matplotlib.dates as mdates


# ---------------------------------------------------------------------------
# 4. MAIN ANALYSIS PIPELINE
# ---------------------------------------------------------------------------

def analyze_market(
    slug: Optional[str] = None,
    token_id: Optional[str] = None,
    condition_id: Optional[str] = None,
    config: Optional[VPINConfig] = None,
    max_trades: int = 10000,
    days_back: int = 30,
    save_path: Optional[str] = None,
) -> dict:
    """
    Full pipeline: fetch market → get trades → run VPIN → visualize.

    Provide ONE of: slug, token_id, or condition_id.
    """
    if config is None:
        config = VPINConfig()

    since = datetime.now(timezone.utc) - timedelta(days=days_back)

    # --- Step 1: Resolve market metadata ---
    market = None
    if slug:
        print(f"\n🔍 Looking up market: {slug}")
        market = fetch_market_by_slug(slug)
    elif condition_id:
        print(f"\n🔍 Looking up market: {condition_id}")
        market = fetch_market_by_id(condition_id)

    if market:
        print(f"  Market: {market.get('question', 'N/A')}")
        print(f"  Volume: ${float(market.get('volume', 0)):,.0f}")
        print(f"  Liquidity: ${float(market.get('liquidity', 0)):,.0f}")

        if not token_id:
            tokens = get_token_ids(market)
            if not tokens:
                raise ValueError("No tokens found for this market")
            print(f"  Tokens: {', '.join(t['outcome'] + '=' + t['token_id'][:12] + '...' for t in tokens)}")
            # Default to YES token
            token_id = tokens[0]["token_id"]
            print(f"  → Analyzing '{tokens[0]['outcome']}' token")
    else:
        market = {"question": f"Token {token_id[:16]}..."}

    # --- Step 2: Fetch trades ---
    print(f"\n📥 Fetching trades (last {days_back} days, max {max_trades})...")
    trades_df = fetch_trades(token_id, max_trades=max_trades, since=since)

    if len(trades_df) < 50:
        print(f"  ⚠ Only {len(trades_df)} trades found. Need at least 50 for meaningful VPIN.")
        print("    Try --days-back 90 or a more active market.")
        return {"trades_raw": trades_df, "market": market}

    print(f"  Trade period: {trades_df['timestamp'].min()} → {trades_df['timestamp'].max()}")
    print(f"  Price range: {trades_df['price'].min():.3f} — {trades_df['price'].max():.3f}")
    print(f"  Total volume: {trades_df['size'].sum():,.0f} contracts")

    # --- Step 3: Preprocess ---
    prices, volumes, timestamps = preprocess_trades(trades_df)

    # Auto-tune bucket size if needed (target ~200-500 buckets)
    total_vol = volumes.sum()
    ideal_buckets = 300
    auto_bucket_size = max(10, int(total_vol / ideal_buckets))
    if config.volume_bucket_size == 50:  # default, auto-tune
        config.volume_bucket_size = auto_bucket_size
        print(f"\n⚙  Auto-tuned bucket size to {config.volume_bucket_size} "
              f"(targeting ~{ideal_buckets} buckets)")

    # --- Step 4: Run VPIN ---
    print(f"\n📊 Running VPIN analysis...")
    print(f"   Bucket size: {config.volume_bucket_size}")
    print(f"   Window: {config.n_buckets_window} buckets")
    print(f"   Alert threshold: {config.alert_threshold}")

    result = run_vpin_pipeline(prices, volumes, timestamps, config)
    buckets = result["buckets"]
    alerts = result["alerts"]

    # --- Step 5: Report ---
    print(f"\n{'=' * 60}")
    print(f"  VPIN RESULTS — {market.get('question', 'N/A')[:50]}")
    print(f"{'=' * 60}")
    print(f"  Total trades analyzed: {len(prices):,}")
    print(f"  Volume buckets: {len(buckets)}")
    print(f"  VPIN range: {buckets['vpin'].min():.3f} — {buckets['vpin'].max():.3f}")
    print(f"  Mean VPIN: {buckets['vpin'].mean():.3f}")
    print(f"  Current VPIN: {buckets['vpin'].iloc[-1]:.3f}")
    print(f"  Alert buckets: {len(alerts)} ({len(alerts)/len(buckets)*100:.1f}%)")

    if len(alerts) > 0:
        print(f"\n  ⚠  HIGH VPIN PERIODS DETECTED:")
        # Group consecutive alerts into episodes
        alert_ids = alerts["bucket_id"].values
        episodes = []
        start = alert_ids[0]
        prev = alert_ids[0]
        for bid in alert_ids[1:]:
            if bid > prev + 2:  # gap of 2+ buckets = new episode
                episodes.append((start, prev))
                start = bid
            prev = bid
        episodes.append((start, prev))

        for ep_start, ep_end in episodes[-5:]:  # show last 5 episodes
            ep_data = buckets[(buckets["bucket_id"] >= ep_start) &
                              (buckets["bucket_id"] <= ep_end)]
            peak_vpin = ep_data["vpin"].max()
            print(f"    Buckets {ep_start}–{ep_end}: "
                  f"peak VPIN = {peak_vpin:.3f}, "
                  f"duration = {ep_end - ep_start + 1} buckets")
    else:
        print(f"\n  ✓ No elevated informed trading detected.")

    # --- Step 6: Plot ---
    if save_path is None:
        save_path = f"vpin_{slug or token_id[:16]}.png"
    plot_polymarket_vpin(result, market, save_path=save_path)

    # Attach raw data for further analysis
    result["trades_raw"] = trades_df
    result["market"] = market
    return result


# ---------------------------------------------------------------------------
# 5. MARKET SCANNER — Scan multiple markets for high VPIN
# ---------------------------------------------------------------------------

def scan_markets(
    n_markets: int = 20,
    config: Optional[VPINConfig] = None,
    max_trades: int = 5000,
    days_back: int = 14,
) -> pd.DataFrame:
    """
    Scan the most active Polymarket markets and rank by VPIN.
    Useful for finding which markets currently have the most
    informed trading activity.
    """
    if config is None:
        config = VPINConfig()

    print(f"\n🔎 Scanning top {n_markets} markets by volume...")
    markets = fetch_markets(limit=n_markets, active=True, sort_by="volume")

    results = []

    for i, market in enumerate(markets):
        question = market.get("question", "?")[:60]
        print(f"\n[{i+1}/{len(markets)}] {question}")

        try:
            tokens = get_token_ids(market)
            if not tokens:
                print("  → No tokens, skipping")
                continue

            token_id = tokens[0]["token_id"]
            since = datetime.now(timezone.utc) - timedelta(days=days_back)
            trades_df = fetch_trades(token_id, max_trades=max_trades, since=since)

            if len(trades_df) < 50:
                print(f"  → Only {len(trades_df)} trades, skipping")
                continue

            prices, volumes, timestamps = preprocess_trades(trades_df)

            # Auto-tune bucket size
            auto_cfg = VPINConfig(
                volume_bucket_size=max(10, int(volumes.sum() / 200)),
                n_buckets_window=config.n_buckets_window,
                sigma_window=config.sigma_window,
                alert_threshold=config.alert_threshold,
            )

            result = run_vpin_pipeline(prices, volumes, timestamps, auto_cfg)
            buckets = result["buckets"]

            current_vpin = buckets["vpin"].iloc[-1]
            max_vpin = buckets["vpin"].max()
            mean_vpin = buckets["vpin"].mean()
            n_alerts = len(result["alerts"])

            results.append({
                "market": question,
                "slug": market.get("slug", ""),
                "volume": float(market.get("volume", 0)),
                "n_trades": len(trades_df),
                "current_vpin": current_vpin,
                "max_vpin": max_vpin,
                "mean_vpin": mean_vpin,
                "alert_buckets": n_alerts,
                "total_buckets": len(buckets),
                "alert_pct": n_alerts / len(buckets) * 100 if len(buckets) > 0 else 0,
            })

            print(f"  → VPIN: current={current_vpin:.3f}, max={max_vpin:.3f}, "
                  f"alerts={n_alerts}")

        except Exception as e:
            print(f"  → Error: {e}")
            continue

    if not results:
        print("\n⚠ No markets analyzed successfully.")
        return pd.DataFrame()

    df = pd.DataFrame(results).sort_values("current_vpin", ascending=False)

    print(f"\n{'=' * 80}")
    print(f"  MARKET SCAN RESULTS — Ranked by Current VPIN")
    print(f"{'=' * 80}")
    print(f"{'Market':<45} {'Cur VPIN':>9} {'Max VPIN':>9} {'Alerts':>8} {'Volume':>12}")
    print(f"{'—' * 80}")
    for _, row in df.head(15).iterrows():
        flag = " ⚠" if row["current_vpin"] >= config.alert_threshold else ""
        print(f"{row['market']:<45} {row['current_vpin']:>9.3f} {row['max_vpin']:>9.3f} "
              f"{row['alert_pct']:>7.1f}% ${row['volume']:>11,.0f}{flag}")

    return df


# ---------------------------------------------------------------------------
# 6. CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="VPIN Insider Trading Detection for Polymarket",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze a specific market
  python polymarket_vpin.py --slug "will-trump-win-the-2024-presidential-election"

  # Scan top markets for informed trading
  python polymarket_vpin.py --scan --n-markets 25

  # Custom parameters
  python polymarket_vpin.py --slug "some-market" --bucket-size 100 --window 40 --threshold 0.5 --days 60
        """,
    )

    # Market selection
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--slug", type=str, help="Market URL slug")
    group.add_argument("--token-id", type=str, help="CLOB token ID directly")
    group.add_argument("--condition-id", type=str, help="Market condition ID")
    group.add_argument("--scan", action="store_true", help="Scan top markets")
    group.add_argument("--list-markets", action="store_true", help="List active markets")

    # VPIN parameters
    parser.add_argument("--bucket-size", type=int, default=50, help="Volume bucket size (default: auto)")
    parser.add_argument("--window", type=int, default=30, help="Rolling window in buckets (default: 30)")
    parser.add_argument("--threshold", type=float, default=0.4, help="Alert threshold (default: 0.4)")
    parser.add_argument("--sigma-window", type=int, default=20, help="Volatility estimation window")

    # Data parameters
    parser.add_argument("--days", type=int, default=30, help="Days of history to fetch (default: 30)")
    parser.add_argument("--max-trades", type=int, default=10000, help="Max trades to fetch (default: 10000)")
    parser.add_argument("--n-markets", type=int, default=20, help="Markets to scan (with --scan)")
    parser.add_argument("--output", type=str, default=None, help="Output plot filename")

    args = parser.parse_args()

    config = VPINConfig(
        volume_bucket_size=args.bucket_size,
        n_buckets_window=args.window,
        alert_threshold=args.threshold,
        sigma_window=args.sigma_window,
    )

    if args.list_markets:
        print("\n📋 Active Polymarket Markets (by volume):\n")
        markets = fetch_markets(limit=30, active=True, sort_by="volume")
        for i, m in enumerate(markets):
            vol = float(m.get("volume", 0))
            print(f"  {i+1:>3}. {m.get('question', '?')[:65]:<65} ${vol:>12,.0f}")
            print(f"       slug: {m.get('slug', 'N/A')}")
        return

    if args.scan:
        scan_markets(
            n_markets=args.n_markets,
            config=config,
            max_trades=args.max_trades,
            days_back=args.days,
        )
        return

    if not args.slug and not args.token_id and not args.condition_id:
        parser.print_help()
        print("\n💡 Try: python polymarket_vpin.py --list-markets")
        return

    analyze_market(
        slug=args.slug,
        token_id=args.token_id,
        condition_id=args.condition_id,
        config=config,
        max_trades=args.max_trades,
        days_back=args.days,
        save_path=args.output,
    )


if __name__ == "__main__":
    main()
