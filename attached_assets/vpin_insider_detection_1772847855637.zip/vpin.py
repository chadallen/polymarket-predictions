"""
VPIN (Volume-Synchronized Probability of Informed Trading)
==========================================================
Based on Easley, López de Prado & O'Hara (2012)
"Flow Toxicity and Liquidity in a High-Frequency World"

This implementation includes:
1. Bulk Volume Classification (BVC) to classify trade volume as buy/sell
2. Volume bucketing (volume clock instead of time clock)
3. Rolling VPIN computation
4. Visualization and alert generation

Designed for use with prediction market data (e.g., Polymarket on-chain trades).
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from scipy.stats import norm
from dataclasses import dataclass
from typing import Optional
import warnings

warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# 1. DATA STRUCTURES
# ---------------------------------------------------------------------------

@dataclass
class VPINConfig:
    """Configuration for VPIN computation."""
    volume_bucket_size: int = 50          # trades per volume bucket
    n_buckets_window: int = 30            # rolling window of buckets for VPIN
    sigma_window: int = 20                # window for estimating price volatility
    alert_threshold: float = 0.4          # VPIN level that triggers an alert
    n_time_bars: int = 1                  # number of time bars for BVC (1 = trade-level)


# ---------------------------------------------------------------------------
# 2. BULK VOLUME CLASSIFICATION (BVC)
# ---------------------------------------------------------------------------

def bulk_volume_classification(prices: np.ndarray, volumes: np.ndarray,
                                sigma: float) -> tuple[np.ndarray, np.ndarray]:
    """
    Classify each trade's volume as buy or sell using the BVC approach.

    BVC uses the normalized price change Z = ΔP / σ and the CDF of the
    standard normal to probabilistically assign volume:
        V_buy  = V * Φ(Z)
        V_sell = V * (1 - Φ(Z))

    Parameters
    ----------
    prices : array of trade prices
    volumes : array of trade volumes
    sigma : estimated price standard deviation

    Returns
    -------
    buy_volume, sell_volume : arrays of classified volumes
    """
    delta_p = np.diff(prices, prepend=prices[0])

    # Avoid division by zero
    if sigma <= 0:
        sigma = 1e-8

    z = delta_p / sigma
    buy_pct = norm.cdf(z)

    buy_volume = volumes * buy_pct
    sell_volume = volumes * (1 - buy_pct)

    return buy_volume, sell_volume


def estimate_sigma(prices: np.ndarray, window: int = 20) -> np.ndarray:
    """
    Rolling standard deviation of price changes for BVC normalization.
    Uses expanding window at the start to avoid NaNs.
    """
    returns = np.diff(prices, prepend=prices[0])
    sigma = pd.Series(returns).rolling(window, min_periods=2).std().bfill().values
    sigma = np.where(np.isnan(sigma), np.nanmean(sigma) if np.any(~np.isnan(sigma)) else 1e-4, sigma)
    sigma = np.maximum(sigma, 1e-8)  # floor to avoid zero
    return sigma


# ---------------------------------------------------------------------------
# 3. VOLUME BUCKETING
# ---------------------------------------------------------------------------

def create_volume_buckets(buy_volume: np.ndarray, sell_volume: np.ndarray,
                          bucket_size: int) -> pd.DataFrame:
    """
    Group trades into fixed-volume buckets (volume clock).

    Each bucket accumulates trades until total volume >= bucket_size.
    Within each bucket we track total buy volume and sell volume.

    Returns
    -------
    DataFrame with columns: bucket_id, total_volume, buy_volume, sell_volume,
                            order_imbalance
    """
    total_volume = buy_volume + sell_volume
    cumulative = np.cumsum(total_volume)

    bucket_ids = (cumulative // bucket_size).astype(int)

    df = pd.DataFrame({
        "bucket_id": bucket_ids,
        "buy_volume": buy_volume,
        "sell_volume": sell_volume,
        "total_volume": total_volume,
    })

    buckets = df.groupby("bucket_id").agg(
        buy_volume=("buy_volume", "sum"),
        sell_volume=("sell_volume", "sum"),
        total_volume=("total_volume", "sum"),
        n_trades=("total_volume", "count"),
    ).reset_index()

    # Order imbalance = |V_buy - V_sell|
    buckets["order_imbalance"] = np.abs(buckets["buy_volume"] - buckets["sell_volume"])

    return buckets


# ---------------------------------------------------------------------------
# 4. VPIN COMPUTATION
# ---------------------------------------------------------------------------

def compute_vpin(buckets: pd.DataFrame, n_window: int) -> pd.DataFrame:
    """
    Compute VPIN as rolling average of order imbalance / total volume.

    VPIN_t = (1/n) * Σ |V_buy_τ - V_sell_τ| / V_bucket

    Parameters
    ----------
    buckets : DataFrame from create_volume_buckets
    n_window : number of buckets in the rolling window

    Returns
    -------
    DataFrame with VPIN series appended
    """
    buckets = buckets.copy()

    # Normalized imbalance per bucket
    buckets["norm_imbalance"] = buckets["order_imbalance"] / buckets["total_volume"]

    # Rolling mean = VPIN
    buckets["vpin"] = (
        buckets["norm_imbalance"]
        .rolling(window=n_window, min_periods=1)
        .mean()
    )

    return buckets


# ---------------------------------------------------------------------------
# 5. FULL PIPELINE
# ---------------------------------------------------------------------------

def run_vpin_pipeline(
    prices: np.ndarray,
    volumes: np.ndarray,
    timestamps: Optional[np.ndarray] = None,
    config: VPINConfig = VPINConfig(),
) -> dict:
    """
    End-to-end VPIN computation.

    Parameters
    ----------
    prices : array of trade prices (e.g., prediction market contract price 0-1)
    volumes : array of trade sizes
    timestamps : optional array of trade timestamps
    config : VPINConfig with hyperparameters

    Returns
    -------
    dict with keys:
        - 'buckets': DataFrame of volume buckets with VPIN
        - 'alerts': DataFrame of buckets where VPIN > threshold
        - 'config': the config used
        - 'trades': DataFrame of trade-level data with classifications
    """
    # Step 1: Estimate rolling volatility
    sigma = estimate_sigma(prices, window=config.sigma_window)

    # Step 2: Bulk volume classification (trade-level, per-trade sigma)
    mean_sigma = np.nanmean(sigma)
    if np.isnan(mean_sigma) or mean_sigma <= 0:
        mean_sigma = np.std(np.diff(prices)) if len(prices) > 1 else 1e-4
    buy_vol, sell_vol = bulk_volume_classification(prices, volumes, mean_sigma)

    # Step 3: Volume bucketing
    buckets = create_volume_buckets(buy_vol, sell_vol, config.volume_bucket_size)

    # Step 4: VPIN
    buckets = compute_vpin(buckets, config.n_buckets_window)

    # Step 5: Alerts
    alerts = buckets[buckets["vpin"] >= config.alert_threshold].copy()

    # Trade-level data for inspection
    trades = pd.DataFrame({
        "price": prices,
        "volume": volumes,
        "buy_volume": buy_vol,
        "sell_volume": sell_vol,
        "sigma": sigma,
    })
    if timestamps is not None:
        trades["timestamp"] = timestamps

    return {
        "buckets": buckets,
        "alerts": alerts,
        "config": config,
        "trades": trades,
    }


# ---------------------------------------------------------------------------
# 6. SYNTHETIC DATA GENERATOR (for testing / demo)
# ---------------------------------------------------------------------------

def generate_synthetic_prediction_market(
    n_trades: int = 5000,
    base_price: float = 0.50,
    resolution_price: float = 1.0,
    insider_start_pct: float = 0.70,   # insiders start trading at 70% through
    insider_intensity: float = 3.0,     # multiplier on volume
    noise_std: float = 0.01,
    seed: int = 42,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    """
    Generate synthetic prediction market data with an insider trading period.

    The market starts at base_price, drifts randomly, then insiders begin
    pushing the price toward resolution_price starting at insider_start_pct
    of the way through the data.

    Returns: prices, volumes, timestamps, insider_start_index
    """
    rng = np.random.default_rng(seed)

    insider_start = int(n_trades * insider_start_pct)

    prices = np.zeros(n_trades)
    volumes = np.zeros(n_trades)
    prices[0] = base_price

    # Generate timestamps (roughly 1 trade per minute)
    start_time = pd.Timestamp("2025-01-15 09:00:00")
    timestamps = pd.date_range(start=start_time, periods=n_trades, freq="1min")

    for i in range(1, n_trades):
        if i < insider_start:
            # Normal period: random walk
            shock = rng.normal(0, noise_std)
            prices[i] = np.clip(prices[i - 1] + shock, 0.01, 0.99)
            volumes[i] = rng.poisson(10)
        else:
            # Insider period: strong drift toward resolution + much higher volume
            progress = (i - insider_start) / (n_trades - insider_start)
            drift = (resolution_price - prices[i - 1]) * 0.02 * (1 + 2 * progress)
            shock = rng.normal(0, noise_std * 0.3)
            prices[i] = np.clip(prices[i - 1] + drift + shock, 0.01, 0.99)

            # Insiders trade with large, directional volume
            base_vol = rng.poisson(10)
            insider_vol = rng.poisson(int(15 * insider_intensity * (0.5 + progress)))
            volumes[i] = base_vol + insider_vol

    volumes[0] = rng.poisson(10)

    return prices, volumes, timestamps.values, insider_start


# ---------------------------------------------------------------------------
# 7. VISUALIZATION
# ---------------------------------------------------------------------------

def plot_vpin_analysis(result: dict, insider_start_idx: Optional[int] = None,
                       save_path: Optional[str] = None):
    """
    Create a multi-panel visualization of VPIN analysis.
    """
    trades = result["trades"]
    buckets = result["buckets"]
    config = result["config"]

    fig, axes = plt.subplots(4, 1, figsize=(14, 12), sharex=False,
                              gridspec_kw={"hspace": 0.35})

    # --- Panel 1: Price ---
    ax1 = axes[0]
    ax1.plot(trades["price"].values, color="#2563eb", linewidth=0.7, alpha=0.9)
    ax1.set_ylabel("Contract Price", fontsize=10)
    ax1.set_title("Prediction Market — VPIN Insider Trading Detection", fontsize=13, fontweight="bold")
    if insider_start_idx is not None:
        ax1.axvline(insider_start_idx, color="#dc2626", linestyle="--", alpha=0.7,
                     label=f"Insider trading begins (trade #{insider_start_idx})")
        ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)

    # --- Panel 2: Volume ---
    ax2 = axes[1]
    ax2.bar(range(len(trades)), trades["volume"].values, color="#6366f1", alpha=0.5, width=1.0)
    ax2.set_ylabel("Trade Volume", fontsize=10)
    if insider_start_idx is not None:
        ax2.axvline(insider_start_idx, color="#dc2626", linestyle="--", alpha=0.7)
    ax2.grid(True, alpha=0.3)

    # --- Panel 3: Order Imbalance per bucket ---
    ax3 = axes[2]
    ax3.bar(buckets["bucket_id"], buckets["norm_imbalance"],
            color="#f59e0b", alpha=0.6, width=1.0)
    ax3.set_ylabel("Normalized\nOrder Imbalance", fontsize=10)
    ax3.grid(True, alpha=0.3)

    # --- Panel 4: VPIN ---
    ax4 = axes[3]
    ax4.plot(buckets["bucket_id"], buckets["vpin"],
             color="#059669", linewidth=1.5, label="VPIN")
    ax4.axhline(config.alert_threshold, color="#dc2626", linestyle="--",
                linewidth=1.2, label=f"Alert threshold ({config.alert_threshold})")
    ax4.fill_between(buckets["bucket_id"], buckets["vpin"], config.alert_threshold,
                     where=buckets["vpin"] >= config.alert_threshold,
                     color="#dc2626", alpha=0.2)
    ax4.set_ylabel("VPIN", fontsize=10)
    ax4.set_xlabel("Volume Bucket", fontsize=10)
    ax4.legend(fontsize=9)
    ax4.set_ylim(0, 1)
    ax4.grid(True, alpha=0.3)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Plot saved to {save_path}")

    plt.close()
    return fig


# ---------------------------------------------------------------------------
# 8. MAIN — Demo with synthetic data
# ---------------------------------------------------------------------------

if __name__ == "__main__":

    print("=" * 65)
    print("  VPIN — Volume-Synchronized Probability of Informed Trading")
    print("  Demo with synthetic prediction market data")
    print("=" * 65)

    # Generate synthetic market with insider trading
    prices, volumes, timestamps, insider_start = generate_synthetic_prediction_market(
        n_trades=5000,
        base_price=0.45,
        resolution_price=1.0,
        insider_start_pct=0.70,
        insider_intensity=3.0,
    )

    print(f"\nGenerated {len(prices)} synthetic trades")
    print(f"Insider trading begins at trade #{insider_start} (70% of data)")
    print(f"Price range: {prices.min():.3f} — {prices.max():.3f}")
    print(f"Mean volume (normal):  {volumes[:insider_start].mean():.1f}")
    print(f"Mean volume (insider): {volumes[insider_start:].mean():.1f}")

    # Configure VPIN
    config = VPINConfig(
        volume_bucket_size=50,
        n_buckets_window=30,
        sigma_window=20,
        alert_threshold=0.4,
    )

    # Run pipeline
    result = run_vpin_pipeline(prices, volumes, timestamps, config)

    buckets = result["buckets"]
    alerts = result["alerts"]

    print(f"\n{'—' * 50}")
    print(f"Volume buckets created: {len(buckets)}")
    print(f"VPIN range: {buckets['vpin'].min():.3f} — {buckets['vpin'].max():.3f}")
    print(f"Mean VPIN:  {buckets['vpin'].mean():.3f}")
    print(f"Alert buckets (VPIN ≥ {config.alert_threshold}): {len(alerts)}")

    if len(alerts) > 0:
        print(f"\n⚠  ALERTS — Buckets with elevated informed trading probability:")
        print(f"{'Bucket':>8} {'VPIN':>8} {'Buy Vol':>10} {'Sell Vol':>10} {'Imbalance':>10}")
        print(f"{'—' * 50}")
        for _, row in alerts.tail(15).iterrows():
            print(f"{int(row['bucket_id']):>8} {row['vpin']:>8.3f} "
                  f"{row['buy_volume']:>10.1f} {row['sell_volume']:>10.1f} "
                  f"{row['order_imbalance']:>10.1f}")

    # Plot
    save_path = "/mnt/user-data/outputs/vpin_analysis.png"
    plot_vpin_analysis(result, insider_start_idx=insider_start, save_path=save_path)

    # --- Summary statistics ---
    print(f"\n{'=' * 65}")
    print("  DETECTION SUMMARY")
    print(f"{'=' * 65}")

    # Compare VPIN before and after insider start
    # Map insider_start trade index to bucket via cumulative volume
    approx_insider_bucket = int(volumes[:insider_start].sum() // config.volume_bucket_size)
    pre = buckets[buckets["bucket_id"] < approx_insider_bucket]["vpin"]
    post = buckets[buckets["bucket_id"] >= approx_insider_bucket]["vpin"]

    print(f"\n  Mean VPIN (pre-insider):   {pre.mean():.3f}")
    print(f"  Mean VPIN (post-insider):  {post.mean():.3f}")
    print(f"  Max VPIN (pre-insider):    {pre.max():.3f}")
    print(f"  Max VPIN (post-insider):   {post.max():.3f}")
    print(f"  Max VPIN observed:         {buckets['vpin'].max():.3f}")

    # What fraction of alert buckets fall in the insider period?
    if len(alerts) > 0:
        n_alerts_insider = len(alerts[alerts["bucket_id"] >= approx_insider_bucket])
        print(f"  Alert buckets in insider period: {n_alerts_insider}/{len(alerts)} "
              f"({n_alerts_insider / len(alerts) * 100:.0f}%)")

    print(f"\n  → The model {'detected' if len(alerts) > 0 else 'did NOT detect'} "
          f"elevated informed trading.\n")
