# VPIN Insider Trading Detection — Replit Integration Guide

## What This Is

A multi-signal insider trading detection engine for prediction markets (Polymarket). It replaces simple scoring algorithms with a research-grade approach based on the VPIN (Volume-Synchronized Probability of Informed Trading) model from Easley, López de Prado & O'Hara (2012), combined with on-chain wallet clustering for entity resolution.

## File Overview

| File | Purpose | Key Exports |
|------|---------|-------------|
| `detection_api.py` | **Main entry point.** Unified API that combines all signals into a single risk score. | `InsiderDetector`, `RiskScore` |
| `vpin.py` | Core VPIN computation engine. Volume bucketing, bulk volume classification, rolling VPIN. | `VPINConfig`, `run_vpin_pipeline` |
| `wallet_clustering.py` | On-chain wallet entity resolution. Links sybil wallets via funding, timing, and behavioral analysis. | `WalletClusterer`, `ClusterConfig` |
| `polymarket_vpin.py` | Polymarket API integration. Fetches trades from CLOB/Gamma APIs. | `fetch_trades`, `fetch_markets`, `analyze_market`, `scan_markets` |
| `requirements.txt` | Python dependencies. | — |

## Quick Start — Replacing Your Existing Scoring

### Before (your simple scoring algo):
```python
# Your existing code probably looks something like:
def score_market(trades):
    # some simple heuristic
    return suspicious_score
```

### After (drop-in replacement):
```python
from detection_api import InsiderDetector

detector = InsiderDetector()

# Option A: Score from trade data you already have
# trades_df needs columns: price, size, timestamp
# Optional columns: wallet, side, token_id
score = detector.score_from_trades(trades_df, market_name="My Market")

print(score.overall_score)      # float 0-1, composite risk
print(score.vpin_current)       # current VPIN level
print(score.confidence)         # 'high', 'medium', 'low'
print(score.to_dict())          # everything as a dict
print(score.to_json())          # everything as JSON

# Option B: Score a Polymarket market directly by slug
score = detector.score_market(slug="will-x-happen")

# Option C: Scan top N markets, ranked by risk
rankings = detector.scan_top_markets(n=20)
```

## RiskScore Schema

The `RiskScore` dataclass is the output of all scoring methods. Here's every field:

```python
@dataclass
class RiskScore:
    overall_score: float        # [0-1] Composite risk. 0=clean, 1=very suspicious
    vpin_current: float         # [0-1] Most recent VPIN value
    vpin_max: float             # [0-1] Peak VPIN in window
    vpin_mean: float            # [0-1] Average VPIN
    vpin_trend: float           # [-1,1] VPIN direction. Positive = getting riskier
    volume_anomaly: float       # [0-1] How unusual recent volume is vs baseline
    price_drift_score: float    # [0-1] Is price drifting to 0/1 faster than expected?
    n_alert_buckets: int        # Number of high-VPIN buckets
    alert_pct: float            # % of buckets that triggered alerts
    entity_concentration: float # [0-1] How concentrated volume is among few entities
    n_trades: int               # Trades analyzed
    confidence: str             # 'high' (500+), 'medium' (100+), 'low' (<100)
    details: dict               # Metadata (market name, price range, etc.)
```

### Interpreting `overall_score`:
- **0.0 – 0.2**: Low risk. Normal trading patterns.
- **0.2 – 0.4**: Moderate. Some signals elevated. Worth monitoring.
- **0.4 – 0.6**: High. Multiple signals triggered. Investigate.
- **0.6 – 1.0**: Very high. Strong evidence of informed trading.

## Integration Patterns

### Pattern 1: REST API endpoint

If your Replit app has a Flask/FastAPI backend:

```python
from flask import Flask, jsonify, request
from detection_api import InsiderDetector

app = Flask(__name__)
detector = InsiderDetector()

@app.route("/api/score", methods=["POST"])
def score_market():
    data = request.json
    trades_df = pd.DataFrame(data["trades"])
    score = detector.score_from_trades(trades_df, market_name=data.get("name", ""))
    return jsonify(score.to_dict())

@app.route("/api/score/<slug>")
def score_by_slug(slug):
    score = detector.score_market(slug=slug)
    return jsonify(score.to_dict())

@app.route("/api/scan")
def scan():
    n = request.args.get("n", 20, type=int)
    results = detector.scan_top_markets(n=n)
    return jsonify(results.to_dict(orient="records"))
```

### Pattern 2: Background job / cron

If you want to scan markets periodically:

```python
from detection_api import InsiderDetector
import schedule
import time

detector = InsiderDetector()

def run_scan():
    results = detector.scan_top_markets(n=30)
    high_risk = results[results["overall_score"] >= 0.4]
    if len(high_risk) > 0:
        # Trigger alerts (webhook, email, DB write, etc.)
        for _, row in high_risk.iterrows():
            alert(row["details"]["market"], row["overall_score"])

schedule.every(1).hours.do(run_scan)
while True:
    schedule.run_pending()
    time.sleep(60)
```

### Pattern 3: Feeding your own trade data

If you're already fetching trades from Polymarket or another source:

```python
import pandas as pd
from detection_api import InsiderDetector

detector = InsiderDetector()

# Your trades need at minimum: price, size, timestamp
# Add 'wallet' column if you have it (enables entity clustering)
# Add 'side' column if you have it (buy/sell, improves accuracy)
# Add 'token_id' column if multi-market (enables cross-market analysis)

trades_df = pd.DataFrame({
    "price": [...],
    "size": [...],
    "timestamp": [...],
    "wallet": [...],       # optional but recommended
    "side": [...],          # optional
    "token_id": [...],      # optional
})

# For wallet clustering, also provide funding/transfer data:
transfers_df = pd.DataFrame({
    "from_address": [...],
    "to_address": [...],
    "value": [...],
    "timestamp": [...],
})

score = detector.score_from_trades(trades_df, transfers=transfers_df)
```

### Pattern 4: Dashboard data

If your app displays risk data in a frontend:

```python
# Return structured data for charts/dashboards
result = detector.score_from_trades(trades_df)

# For a risk gauge/meter
gauge_data = {
    "score": result.overall_score,
    "label": "HIGH" if result.overall_score >= 0.4 else "NORMAL",
    "confidence": result.confidence,
}

# For a signal breakdown chart
signals = {
    "VPIN": result.vpin_current,
    "Volume Anomaly": result.volume_anomaly,
    "Price Drift": result.price_drift_score,
    "Entity Concentration": result.entity_concentration,
}

# For a time series chart (VPIN over volume buckets)
# Run the raw pipeline to get bucket-level data:
from vpin import VPINConfig, run_vpin_pipeline
vpin_result = run_vpin_pipeline(prices, volumes, timestamps, VPINConfig())
vpin_timeseries = vpin_result["buckets"][["bucket_id", "vpin"]].to_dict(orient="records")
```

## Tuning Parameters

### VPIN Config
```python
from vpin import VPINConfig

config = VPINConfig(
    volume_bucket_size=50,    # Trades per bucket. Lower = more sensitive, noisier.
    n_buckets_window=30,      # Rolling window. Lower = faster reaction, more false positives.
    sigma_window=20,          # Volatility estimation window.
    alert_threshold=0.4,      # VPIN level that triggers alert. Lower = more alerts.
)
```

### Wallet Clustering Config
```python
from wallet_clustering import ClusterConfig

config = ClusterConfig(
    funding_hop_depth=3,          # Hops to trace funding. More = catches laundering, slower.
    time_window_seconds=60,       # Co-trading window. Tighter = fewer false links.
    similarity_threshold=0.35,    # Min similarity to link wallets. Lower = more clusters.
    min_trades_per_wallet=3,      # Ignore low-activity wallets.
)
```

### Composite Score Weights
```python
from detection_api import InsiderDetector

# Customize which signals matter most for your use case
weights = {
    "vpin_current": 0.25,           # Current informed trading level
    "vpin_max": 0.15,               # Peak informed trading
    "vpin_trend_positive": 0.15,    # Is it getting worse?
    "volume_anomaly": 0.15,         # Unusual volume
    "price_drift": 0.15,            # Price moving to boundary
    "alert_pct": 0.10,              # How many buckets alerted
    "entity_concentration": 0.05,   # Few wallets dominating
}

detector = InsiderDetector(score_weights=weights)
```

## How the Scoring Works Under the Hood

The composite score combines six independent signals:

1. **VPIN (current, max, trend)** — The core signal. Measures order flow imbalance using volume-synchronized buckets and bulk volume classification. Based on Easley, López de Prado & O'Hara (2012). High VPIN = trades are disproportionately one-directional = someone likely knows the outcome.

2. **Volume Anomaly** — Compares recent trading volume to a historical baseline using z-scores. Insiders increase market activity when they trade on private information.

3. **Price Drift** — Measures whether price is moving toward a resolution boundary (0 or 1) faster than historical volatility would predict. A random walk shouldn't consistently drift; informed trading creates directional pressure.

4. **Entity Concentration** — HHI-style measure of how concentrated trading volume is among entities. If 3 wallet clusters account for 80% of volume, that's suspicious. Uses the wallet clustering module for entity resolution.

5. **Alert Frequency** — What fraction of VPIN buckets exceeded the alert threshold. Persistent high VPIN is more concerning than a single spike.

Each signal outputs a 0–1 score. These are combined with configurable weights into the `overall_score`.

## Wallet Clustering — How It Links Wallets

The `WalletClusterer` uses four independent signals to compute pairwise wallet similarity, then runs hierarchical clustering:

1. **Funding Source Analysis** (weight: 0.50) — Traces token/native transfers backward N hops. Wallets with shared funding ancestors (especially intermediate wallets) are likely the same person. This is the strongest signal.

2. **Temporal Clustering** (weight: 0.25) — Counts how often two wallets trade within N seconds of each other on the same contract. Humans controlling multiple wallets via scripts produce correlated timing.

3. **Behavioral Fingerprinting** (weight: 0.15) — Compares order size distributions, active hours, buy/sell ratios, and inter-trade intervals. People have habits that persist across wallets.

4. **Cross-Market Co-movement** (weight: 0.10) — Checks if wallets appear together across multiple markets on the same side. Independently lucky wallets don't cluster.

Similarity scores are combined and hierarchical clustering (average linkage) groups wallets into entities.

## Fetching On-Chain Transfer Data for Wallet Clustering

The wallet clustering module needs transfer data. You can get this from:

### Option A: Polygonscan API
```python
import requests

def get_transfers(wallet, api_key):
    url = "https://api.polygonscan.com/api"
    params = {
        "module": "account",
        "action": "tokentx",             # ERC-20 transfers
        "address": wallet,
        "sort": "desc",
        "apikey": api_key,
    }
    resp = requests.get(url, params=params)
    return resp.json()["result"]
```

### Option B: Alchemy/Infura RPC
```python
# Use eth_getLogs with Transfer event topic for USDC contract on Polygon
```

### Option C: Dune Analytics
Query for all transfers to/from wallets that traded on Polymarket contracts.

## Testing

Each module has a `if __name__ == "__main__"` demo that runs on synthetic data:

```bash
python vpin.py                    # Core VPIN demo with synthetic insider trading
python wallet_clustering.py       # Wallet clustering demo with synthetic sybils
python detection_api.py           # Full scoring pipeline demo
python polymarket_vpin.py --help  # CLI for real Polymarket data
```

## Common Issues

**"Too few trades"**: Markets with <20 trades can't produce meaningful VPIN. Try increasing `--days` or picking a more active market.

**VPIN is always low**: Try reducing `volume_bucket_size` (smaller buckets are more sensitive) or `n_buckets_window` (shorter memory).

**Too many false alerts**: Increase `alert_threshold` or increase `n_buckets_window` for more smoothing.

**Wallet clustering is slow**: It's O(n²) in the number of wallets. For >1000 wallets, increase `min_trades_per_wallet` to filter out noise wallets, or pre-filter to wallets active on the specific contracts you care about.
